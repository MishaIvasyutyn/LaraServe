#!/usr/bin/env bash
RED='\033[0;31m'
GREEN='\033[1;32m'
PURPLE='\033[1;33m'
YELLOW='\033[1;35m'
BLUE='\033[1;34m'
NC='\033[0m' # No Color

if [[ $EUID -eq 0 ]]; then
    echo -e "${RED}This script must be run without  root${NC}"
  exit 1
fi

if [ ! -w "../../laraserve" ] || [ ! -r "../../laraserve" ]; then
   sudo chown -R $USER:$USER
  fi


echo -e "${GREEN}
,--.
|  |    ,--,--.,--.--. ,--,--.
|  |   ' ,-.  ||  .--'' ,-.  |
|  '--.\ '-'  ||  |   \ '-'  |
'-----' '--'--''--'    '--'--'
                               ${NC}"
echo -e "${BLUE}"$'\n' \
  $'                  ##        .\n' \
  $'            ## ## ##       ==\n' \
  $'         ## ## ## ##      ===\n' \
  $'     /""""""""""""""""\___/ ===\n' \
  $'~~~ {~~ ~~~~ ~~~ ~~~~ ~~ ~ /  ===-- ~~~\n' \
  $'     \______ o          __/\n' \
  $'       \    \        __/\n' \
  $'        \____\______/\n'"${NC}"

echo -e "${PURPLE}🐳by Misha               ©${NC}🇲​​​​​🇮​​​​​🇸​​​​​🇭​​​​​🇦​​​​​\n"

host_edit() {
  cd nginx
  mkdir ssl
  cd ssl
  mkcert $project.dev 127.0.0.1
  echo -e "${YELLOW}Edit host file...${NC}"
  sleep 1
  ETC_HOSTS=/etc/hosts
  IP=127.0.0.1
  HOSTNAME=$project'.dev'
  HOSTS_LINE="$IP[[:space:]]$HOSTNAME"
  HOSPUK="$IP $HOSTNAME"
  line_content=$(printf "%s\t%s\n" "$IP" "$HOSTNAME")
  if [ -n "$(grep -P $HOSTS_LINE $ETC_HOSTS)" ]; then
    echo -e "${YELLOW}$line_content already exists : $(grep $HOSTNAME $ETC_HOSTS)${YELLOW}"
    sleep 1
  else
    echo "Adding $line_content to your $ETC_HOSTS"
    sudo -- sh -c -e "echo '$HOSPUK' >> /etc/hosts"
    sleep 1
    if [ -n "$(grep -P $HOSTNAME $ETC_HOSTS)" ]; then
      echo -e "${GREEN}$line_content was added successfully${NC}"
      sleep 1
    else
      echo -e "${RED}Failed to Add $line_content, Try again!${NC}"
      sleep 1
    fi
  fi
  cd ../../../
}
get_dymfile(){
  local type=$1
  if [[ $type == php ]]; then
      cd docker/php
      type=.ini
  elif  [[ $type == mysql ]]; then
    cd docker/mysql
    type=.cnf
  elif  [[ $type == nginx ]]; then
     if [ ! -d "nginx" ]; then
      exit
    fi
    cd nginx/conf.d
    type=.conf
  fi
local FILE
for FILE in `ls *$type`; do
echo $FILE
break;
done
}
stop_service_isexist(){
   if [[ $(sudo netstat -anp | grep ':80 ') ]]; then
    echo -e "${PURPLE}Found server (80) port listener${NC}"
    sleep 1
    echo -e "$1 ${GREEN}Stoping... ${NC}"
    sudo lsof -t -i tcp:80 -s tcp:listen | sudo xargs kill
  fi
    if [[ $(sudo netstat -anp | grep ':3306 ') ]]; then
    echo -e "${PURPLE}Found database (3306) port listener${NC}"
    sleep 1
    echo -e "$1 ${GREEN}Stopping... ${NC}"
    sudo lsof -t -i tcp:3306 -s tcp:listen | sudo xargs kill
  fi
  if [[ $(sudo netstat -anp | grep ':443 ') ]]; then
    echo -e  "${PURPLE}Found ssl server (443) port listener${NC}"
    sleep 1
    echo -e "$1 ${GREEN}Stopping... ${NC}"
    sudo lsof -t -i tcp:443 -s tcp:listen | sudo xargs kill
  fi
    if [[ $(sudo netstat -anp | grep ':8080 ') ]]; then
    echo -e  "${PURPLE}Found 8080 port listener${NC}"
    sleep 1
    echo -e "$1 ${GREEN}Stopping... ${NC}"
    sudo lsof -t -i tcp:8080 -s tcp:listen | sudo xargs kill
  fi
  if [[ $(sudo netstat -anp | grep ':1025 ') ]]; then
    echo -e "${PURPLE}Found mailhog (1025) port listener${NC}"
    sleep 1
    echo -e "$1 ${GREEN}Stopping... ${NC}"
    sudo lsof -t -i tcp:1025 -s tcp:listen | sudo xargs kill
  fi
  if [[ $(sudo netstat -anp | grep ':8025 ') ]]; then
    echo  -e "${PURPLE}Found mailhog (8025) port listener${NC}"
    sleep 1
    echo -e "$1 ${GREEN}Stopping... ${NC}"
    sudo lsof -t -i tcp:8025 -s tcp:listen | sudo xargs kill
  fi
  sleep  3
  echo  -e "${GREEN}All service port stopped${NC}"
}
make_file_ownproject(){
   touch Makefile
  echo 'up:
	docker-compose up -d
build:
	docker-compose build --no-cache --force-rm
remake:
	@make destroy
	@make init
stop:
	docker-compose stop
down:
	docker-compose down --remove-orphans
restart:
	@make down
	@make up
destroy:
	docker-compose down --rmi all --volumes --remove-orphans
destroy-volumes:
	docker-compose down --volumes --remove-orphans
ps:
	docker-compose ps
logs:
	docker-compose logs
logs-watch:
	docker-compose logs --follow
#log-web:
#	docker-compose logs web
#log-web-watch:
#	docker-compose logs --follow web
log-app:
	docker-compose logs app
log-app-watch:
	docker-compose logs --follow app
log-mysql:
	docker-compose logs mysql
log-mysql-watch:
	docker-compose logs --follow mysql
app:
	docker-compose exec app bash
composer-cache:
	docker-compose exec app composer dump-autoload -o
	docker-compose exec app composer dump-autoload
npm:
	@make npm-install
npm-install:
	 npm install
npm-dev:
	 npm run dev
npm-watch:
	 npm run watch
npm-watch-poll:
	npm run watch-poll
npm-hot:
	 npm run hot
yarn:
	 yarn
yarn-install:
	@make yarn
yarn-dev:
	 yarn dev
yarn-watch:
	yarn watch
yarn-watch-poll:
	yarn watch-poll
yarn-hot:
	 yarn hot
mysql:
	docker-compose exec mysql bash
sql:
	docker-compose exec mysql bash -c "mysql -u $$MYSQL_USER -p$$MYSQL_PASSWORD $$MYSQL_DATABASE"
#redis:
#	docker-compose exec redis redis-cli
ngrok:
	ngrok http 443
composer-cache:
	docker-compose exec app composer clear-cache
npm-cache:
	npm cache clean --force
' >Makefile
}
make_file_laravel() {
  touch Makefile
  echo "up:
	docker-compose up -d
build:
	docker-compose build --no-cache --force-rm
laravel-install:
	#docker-compose exec app composer create-project --prefer-dist laravel/laravel .
#create-project:
#	#mkdir -p backend
#	@make build
#	@make up
#	@make laravel-install
#	docker-compose exec app php artisan key:generate
#	docker-compose exec app php artisan storage:link
#	docker-compose exec app chmod -R 777 storage bootstrap/cache
#	@make fresh
install-recommend-packages:
#	docker-compose exec app composer require doctrine/dbal \"^2\"
	#docker-compose exec app composer require --dev ucan-lab/laravel-dacapo
#	docker-compose exec app composer require --dev barryvdh/laravel-ide-helper
	#docker-compose exec app composer require --dev beyondcode/laravel-dump-server
	docker-compose exec app composer require barryvdh/laravel-debugbar --dev
	#docker-compose exec app composer require --dev roave/security-advisories:dev-master
	docker-compose exec app composer require --dev coderello/laravel-populated-factory
#	docker-compose exec app php artisan vendor:publish --provider=\"BeyondCode\\DumpServer\\DumpServerServiceProvider\"
#	docker-compose exec app php artisan vendor:publish --provider=\"Barryvdh\\Debugbar\\ServiceProvider\"
#init:
#	docker-compose up -d --build
#	docker-compose exec app composer install
#	docker-compose exec app cp .env.example .env
#	docker-compose exec app php artisan key:generate
#	docker-compose exec app php artisan storage:link
#	docker-compose exec app chmod -R 777 storage bootstrap/cache
#	@make fresh
remake:
	@make destroy
	@make init
stop:
	docker-compose stop
down:
	docker-compose down --remove-orphans
restart:
	@make down
	@make up
destroy:
	docker-compose down --rmi all --volumes --remove-orphans
destroy-volumes:
	docker-compose down --volumes --remove-orphans
ps:
	docker-compose ps
logs:
	docker-compose logs
logs-watch:
	docker-compose logs --follow
#log-web:
#	docker-compose logs web
#log-web-watch:
#	docker-compose logs --follow web
log-app:
	docker-compose logs app
log-app-watch:
	docker-compose logs --follow app
log-mysql:
	docker-compose logs mysql
log-mysql-watch:
	docker-compose logs --follow mysql
#web:
#	docker-compose exec web ash
app:
	docker-compose exec app bash
migrate:
	docker-compose exec app php artisan migrate
fresh:
	docker-compose exec app php artisan migrate:fresh --seed
seed:
	docker-compose exec app php artisan db:seed
dacapo:
	docker-compose exec app php artisan dacapo
rollback-test:
	docker-compose exec app php artisan migrate:fresh
	docker-compose exec app php artisan migrate:refresh
tinker:
	docker-compose exec app php artisan tinker
test:
	docker-compose exec app php artisan test
optimize:
	docker-compose exec app php artisan optimize
optimize-clear:
	docker-compose exec app php artisan optimize:clear
cache:
	docker-compose exec app composer dump-autoload -o
#	docker-compose exec app composer dump-autoload
	@make optimize
	docker-compose exec app php artisan event:cache
	docker-compose exec app php artisan view:cache
	docker-compose exec app php artisan config:cache
	docker-compose exec app php artisan route:cache
composer-cache:
	docker-compose exec app composer dump-autoload -o

cache-clear:
	docker-compose exec app composer php artisan cache:clear
	@make optimize-clear
	docker-compose exec app php artisan event:clear
npm:
	@make npm-install
npm-install:
	 npm install
npm-dev:
	 npm run dev
npm-watch:
	 npm run watch
npm-watch-poll:
	npm run watch-poll
npm-hot:
	 npm run hot
yarn:
	 yarn
yarn-install:
	@make yarn
yarn-dev:
	 yarn dev
yarn-watch:
	yarn watch
yarn-watch-poll:
	yarn watch-poll
yarn-hot:
	 yarn hot
mysql:
	docker-compose exec mysql bash
sql:
	docker-compose exec mysql bash -c \"mysql -u \$\$MYSQL_USER -p\$\$MYSQL_PASSWORD \$\$MYSQL_DATABASE\"
sql-restore:
	docker  exec -i  app-mysql bash -c \"exec  mysql -u\$\$MYSQL_USER  -p\$\$MYSQL_PASSWORD  \$\$MYSQL_DATABASE\" < \$\$MYSQL_DATABASE.sql
sql-dump:
  docker  exec   app-mysql bash -c \"exec mysqldump  -u\$\$MYSQL_USER  -p\$\$MYSQL_PASSWORD   \$\$MYSQL_DATABASE\" > docker/mysql/dumps/\$\$MYSQL_DATABASE.sql
#redis:
#	docker-compose exec redis redis-cli
#ide-helper:
#	docker-compose exec app php artisan clear-compiled
#	docker-compose exec app php artisan ide-helper:generate
#	docker-compose exec app php artisan ide-helper:meta
#	docker-compose exec app php artisan ide-helper:models --nowrite
ngrok:
	ngrok http 443
wifi-local:
	hostname -I | awk '{print \$1}'
project-down:
	docker-compose exec app php artisan down
project-up:
	docker-compose exec app php artisan up
composer-cache:
	docker-compose exec app composer clear-cache
npm-cache:
	npm cache clean --force
">Makefile
}
docker_run_ownproject(){
  make_file_ownproject
  if [ ! -w "../$project" ] || [ ! -r "../$project" ]; then
   sudo chown -R $USER:$USER ../$project
  fi
  echo -e "${PURPLE}Stopping  docker containers  if they have been started ${NC}"
  sleep 1
  docker stop $(docker ps -a -q)
  sleep 3
  echo -e "Stopping  additional services if they are running like ngnix, mysql, mailhog"
  stop_service_isexist
  sleep 3
  docker rm $(docker ps -a -f status=exited -q)
  sleep 2
  echo -e "${PURPLE}Building and running docker containers...${NC}"
  docker-compose build app
  docker-compose up -d
  echo -e "${PURPLE}Installing Vendor using composer...${NC}"
  if [ ! -f "composer.json" ]; then
  echo -e "${RED}Error${NC} Can't find composer.json  file "
  exit
  fi
  docker-compose exec app composer install
}
docker_run_laravel() {
  make_file_laravel
  if [ ! -f ".env.example" ]; then
      echo -e "${RED}Error${NC} Can't find file .env.example"
      exit
  fi
  cp .env.example .env
 for file in .env; do
    if grep -q "DB_HOST=" "$file"; then
        sed -i 's/^DB_HOST=.*$/DB_HOST=mysql/' $file
        else
        echo -e "${RED}Error${NC}"
        exit
    fi
    if grep -q "DB_PASSWORD=" "$file"; then
        sed -i 's/^DB_PASSWORD=.*$/DB_PASSWORD=root/' $file
    fi
     if grep -q "APP_NAME=" "$file"; then
      sed -i "s/^APP_NAME=.*$/APP_NAME=$project/" $file
    fi
    if grep -q "APP_DEBUG=" "$file"; then
        sed -i 's/^APP_DEBUG=.*$/APP_DEBUG=true/' $file
    fi
       if grep -q "APP_URL=" "$file"; then
       sed -i "s,^APP_URL=.*$,APP_URL=https://$project.dev," $file
    fi
    if grep -q "MAIL_FROM_ADDRESS=null" "$file"; then
        sed -i "s/^MAIL_FROM_ADDRESS=.*$/MAIL_FROM_ADDRESS=$project@gmail.com/" $file
    fi
    if grep -q "DB_DATABASE=" "$file"; then
        sed -i "s/^DB_DATABASE=.*$/DB_DATABASE=$project/" $file
    fi
    if grep -q "DB_PORT=" "$file"; then
        sed -i "s/^DB_PORT=.*$/DB_PORT=3306/" $file
    fi
    if grep -q "MAIL_PORT=" "$file"; then
        sed -i "s/^MAIL_PORT=.*$/MAIL_PORT=1025/" $file
    fi
    if grep -q "MAIL_MAILER=" "$file"; then
        sed -i "s/^MAIL_MAILER=.*$/MAIL_MAILER=smtp/" $file
    fi
    if grep -q "MAIL_HOST=" "$file"; then
        sed -i "s/^MAIL_HOST=.*$/MAIL_HOST=mailhog/" $file
    fi
done

   if [ ! -w "../$project" ] || [ ! -r "../$project" ]; then
   sudo chown -R $USER:$USER ../$project
  fi
  echo -e "${PURPLE}Stopping  docker containers  if they have been started ${NC}"
  sleep 1
  docker stop $(docker ps -a -q)
  sleep 3
  echo -e "Stopping  additional services if they are running like ngnix, mysql, mailhog"
  stop_service_isexist
  sleep 3
  docker rm $(docker ps -a -f status=exited -q)
  sleep 2
  echo -e "${PURPLE}Building and running docker containers...${NC}"
  docker-compose build app
  docker-compose up -d
  echo -e "${PURPLE}Installing Vendor using composer...${NC}"
  if [ ! -f "composer.json" ]; then
  echo -e "${RED}Error${NC} Can't find composer.json  file "
  exit
  fi
  docker-compose exec app composer install
  echo -e "${PURPLE}Generate key${NC}"
  docker-compose exec app php artisan key:generate
  docker-compose exec app php artisan storage:link
  docker-compose exec app chmod -R 777 storage bootstrap/cache
  docker-compose exec app php artisan migrate
  while true; do
    read -p "Do you wish to install laravel  debug panel? " yn
    case $yn in
        [Yy]* ) docker-compose exec app composer require barryvdh/laravel-debugbar --dev; break;;
        [Nn]* ) break;;
        * ) echo "Please answer yes or no.";;
    esac
done
}
nginx_config() {
local projType=$1
local dirpath
local nginxconf=$(get_dymfile nginx)
if [[ $projType == "laravel" ]]; then
    dirpath=public
 elif [[ $projType == "ownproject" ]]; then
   read -p "Enter path to public folder: " dirpath
while [ -z ${dirpath} ]; do
  read -p "Folder path   can't be empty: " dirpath
done
while [[ $dirpath =~ ^[0-9]+$ ]]; do
  read -p "Please enter a correct path without number:  " dirpath
  while [ -z ${dirpath} ]; do
    read -p "Folder path  can't be empty: " dirpath
  done
done
fi
  local PATTERN="nginx/conf.d/*.conf"
  if [ ! -d "nginx" ]; then
     mkdir nginx
  fi
  if [ ! -d "nginx/conf.d" ]; then
    mkdir -p nginx/conf.d
  fi
  if  ! ls $PATTERN 1> /dev/null 2>&1 ; then
 touch nginx/conf.d/app.conf
  echo "server {
    listen 443 ssl;
    server_name $project.dev;
    ssl_certificate /etc/nginx/ssl/$project.dev+1.pem;
    ssl_certificate_key /etc/nginx/ssl/$project.dev+1-key.pem;
    index index.php index.html;
    error_log  /var/log/nginx/error.log;
    access_log /var/log/nginx/access.log;
    root /var/www/$dirpath;
    ssl on;
    charset utf-8;

    add_header X-Frame-Options \"SAMEORIGIN\";
    add_header X-XSS-Protection \"1; mode=block\";
    add_header X-Content-Type-Options \"nosniff\";

    location ~ \\.php$ {
        try_files \$uri =404;
        fastcgi_split_path_info ^(.+\.php)(/.+)$;
        fastcgi_pass app:9000;
        fastcgi_index index.php;
        include fastcgi_params;
        fastcgi_param SCRIPT_FILENAME \$document_root\$fastcgi_script_name;
        fastcgi_param PATH_INFO \$fastcgi_path_info;
    }
    location / {
        try_files \$uri \$uri/ /index.php?\$query_string;
        gzip_static on;
    }
    location = /favicon.ico { access_log off; log_not_found off; }
    location = /robots.txt  { access_log off; log_not_found off; }

}" >nginx/conf.d/app.conf
elif  [ -f "nginx/conf.d/$nginxconf" ]; then
if grep -q "dynchange" "nginx/conf.d/$nginxconf"; then
sed -i "s/dynchange/$dirpath/g" "nginx/conf.d/$nginxconf"
fi
if grep -q "project" "nginx/conf.d/$nginxconf"; then
sed -i "s/project/$project/g" "nginx/conf.d/$nginxconf"
fi
fi
}
php_config() {
 local PATTERN="php/*.ini"
  if [ ! -d "php" ]; then
     mkdir php
  fi
if  ! ls $PATTERN 1> /dev/null 2>&1 ; then
    touch php/php.ini
    echo 'upload_max_filesize=67M
post_max_size=128M
display_errors = on
error_reporting = E_ALL
[xdebug]
;xdebug.remote_host=host.docker.internal
xdebug.remote_autostart=true
xdebug.remote_mode=req
xdebug.remote_handler=dbgp
xdebug.remote_connect_back=0
xdebug.remote_port=9003
xdebug.idekey=PHPSTORM
xdebug.remote_enable=1
xdebug.profiler_append=0
xdebug.profiler_enable=0
xdebug.profiler_enable_trigger=1
xdebug.var_display_max_data=-1
xdebug.var_display_max_children=-1
;xdebug.var_display_max_depth=-1
xdebug.remote_host =192.168.0.100
xdebug.mode=debug
xdebug.client_host=192.168.0.100
' >php/php.ini
fi
}
mysql_config(){
  local PATTERN="mysql/*.cnf"
  if [ ! -d "mysql" ]; then
     mkdir mysql
  fi
    if [ ! -d "mysql/dumps" ]; then
     mkdir -p  mysql/dumps
  fi
if  ! ls $PATTERN 1> /dev/null 2>&1 ; then
    touch mysql/my.cnf
    echo '[mysqld]
# default
skip-host-cache
skip-name-resolve
datadir = /var/lib/mysql
socket = /var/lib/mysql/mysql.sock
secure-file-priv = /var/lib/mysql-files
user = mysql

general_log = 1
general_log_file = /var/lib/mysql/general.log
' >mysql/my.cnf
fi
}
docker_file() {
if [ ! -f "php/Dockerfile" ]; then
touch php/Dockerfile
echo 'FROM php:7.4-fpm

# Arguments defined in docker-compose.yml
ARG user
ARG uid

# Install system dependencies
RUN apt-get update && apt-get install -y \
    git \
    bash \
    curl \
    libpng-dev \
    libonig-dev \
    libxml2-dev \
    zip \
    libpng-dev zlib1g-dev libicu-dev g++ libmagickwand-dev --no-install-recommends libxml2-dev \
    unzip \
    nodejs \
    npm \
        && docker-php-ext-configure intl \
        && docker-php-ext-install intl \
        && docker-php-ext-install pdo_mysql mbstring exif pcntl bcmath gd xml \
        && pecl install imagick \
        && docker-php-ext-enable imagick \
        && pecl install xdebug-3.0.1 \
        && docker-php-ext-enable xdebug

# Clear cache
RUN apt-get clean && rm -rf /var/lib/apt/lists/*

# Install PHP extensions
RUN docker-php-ext-install pdo_mysql mbstring exif pcntl bcmath gd

# Get latest Composer
COPY --from=composer:latest /usr/bin/composer /usr/bin/composer

# Create system user to run Composer and Artisan Commands
RUN useradd -G www-data,root -u $uid -d /home/$user $user
RUN mkdir -p /home/$user/.composer && \
    chown -R $user:$user /home/$user

# Set working directory
WORKDIR /var/www

USER $user
' >php/Dockerfile
fi
}
docker_compose() {
local proJtype=$1
if [[ $proJtype == "laravel" ]]; then
local network="laravel"
 elif [[ $1 == "ownproject" ]]; then
   local network=$project
fi
local phpconf=$(get_dymfile php)
local mysqlconf=$(get_dymfile mysql)
  if [ ! -f "docker-compose.yml" ]; then
  touch docker-compose.yml
  echo "version: \"3.8\"
services:

  #PHP Service
  app:
    build:
      args:
        user: sammy
        uid: 1000
      context: ./
      dockerfile: docker/php/Dockerfile
    image: laravel
    container_name: app-php
    restart: unless-stopped
    tty: true
    environment:
      SERVICE_NAME: app
      SERVICE_TAGS: dev
    working_dir: /var/www
    volumes:
      - ./:/var/www
      - ./docker/php/$phpconf:/usr/local/etc/php/conf.d/$phpconf
    networks:
      - laravel

  #Nginx Service
  nginx:
    image: nginx:alpine
    container_name: app-server
    restart: unless-stopped
    tty: true
    ports:
      - \"443:443\"
    depends_on:
      - app
    volumes:
      - ./:/var/www
      - ./docker/nginx/conf.d/:/etc/nginx/conf.d/
      - ./docker/nginx/ssl:/etc/nginx/ssl
    networks:
      - laravel

  #MySQL Service
  mysql:
    image: mysql/mysql-server:8.0
    container_name: app-mysql
    restart: unless-stopped
    tty: true
    ports:
      - '\${DB_PORT:-3306}:\${DB_PORT:-3306}'
    environment:
      MYSQL_DATABASE: \${DB_DATABASE:-$project}
      MYSQL_ROOT_PASSWORD: \${DB_PASSWORD:-root}
      MYSQL_PASSWORD: \${DB_PASSWORD:-root}
      MYSQL_USER: \${DB_USERNAME}
      MYSQL_ALLOW_EMPTY_PASSWORD: 'yes'
      SERVICE_TAGS: dev
      SERVICE_NAME: mysql
    volumes:
     - \"${network}mysql:/var/lib/mysql\"
    - ./docker/mysql/$mysqlconf:/etc/mysql/$mysqlconf
    networks:
      - $network

  #PHPMyadmin Service
  phpmydmin:
    image: phpmyadmin/phpmyadmin
    restart: always
    container_name: app-phpmyadmin
    depends_on:
      - mysql
    ports:
      - \"8080:80\"
    environment:
      PMA_HOST: mysql
      MYSQL_ROOT_PASSWORD: root
    networks:
      - $network

    # memcached:
    #     image: \"memcached:alpine\"
    #     ports:
    #         - \"11211:11211\"
    #     networks:
    #         - laravel
  mailhog:
      image: \"mailhog/mailhog:latest\"
      ports:
       - \${MAIL_PORT:-1025}:\${MAIL_PORT:-1025}
       - 8025:8025
      networks:
        - $network

#Docker Networks
networks:
  $network:
    driver: bridge
volumes:
  ${network}mysql:
    driver: local
" >docker-compose.yml
elif  [ -f "docker-compose.yml" ]; then
  if grep -q "dynphp" docker-compose.yml; then
  sed -i "s/dynphp/$phpconf/g" docker-compose.yml
  fi
  if grep -q "dynmysql" docker-compose.yml; then
  sed -i "s/dynmysql/$mysqlconf/g" docker-compose.yml
  fi
  if grep -q "dynetwork" docker-compose.yml; then
sed -i "s/dynetwork/$project/g" docker-compose.yml
  fi
  if grep -q "dyname" docker-compose.yml; then
sed -i "s/dyname/$project/g" docker-compose.yml
  fi
fi
}
docker_own_project(){
 local projType=$1
  if [[ $projType == "laravel" ]]; then
    echo -e "${PURPLE}Creating docker config ...${NC}"
    cp -a ../config/ownproject/laravel/. $project/
    cd $project
    if [ ! -d "docker" ]; then
      mkdir docker
    fi
    cd docker

    php_config

    docker_file

    mysql_config

    nginx_config "laravel"

    host_edit

    docker_compose "laravel"

    docker_run_laravel
    git add .
    git commit -m"initial commit for $project"
    xdg-open https://$project.dev
    echo -e "${PURPLE}Happy coding :) ${NC}"
    sleep 3
    exit
    elif [[ $projType == "another" ]]; then
    echo -e "${PURPLE}Creating docker config ...${NC}"
    cp -a ../config/ownproject/notlaravel/. $project/
    cd $project
    if [ ! -d "docker" ]; then
      mkdir docker
    fi
    cd docker
    php_config

    docker_file

    mysql_config

    nginx_config "ownproject"

    host_edit

    docker_compose "ownproject"

    docker_run_ownproject
    git add .
    git commit -m"initial commit for $project"
    xdg-open https://$project.dev
    echo -e "${PURPLE}Happy coding :) ${NC}"
    sleep 3
    exit
  fi
}
number_validate() {
  local varible=$1
  while [ -z ${varible} ]; do
    read -p "This values can't be empty: " varible
  done

  while ! [[ $varible =~ ^[0-9]+$ ]]; do
    read -p "Please enter a number:  " varible
    while [ -z ${varible} ]; do
      read -p "This values can't be empty: " varible
    done
  done
  echo $varible
}
check_settings_usage() {
  echo -en "${BLUE}Do you want to use your own docker settings or use default - (config/laravel)?${NC}${YELLOW} (1-Default/2-Custom)${NC}: "
  read projconf
  projconf=$(number_validate $projconf)
}

read -p "Enter project name: " project
while [ -z ${project} ]; do
  read -p "Project  name can't be empty: " project
done
while [[ $project =~ [^a-zA-Z] ]]; do
  read -p "Please enter a correct name without number and special characters:  " project
  while [ -z ${project} ]; do
    read -p "Project name can't be empty: " project
  done
done

project=${project,,}
if [ -d "$project" ]; then
  echo -e "${RED}Project already exist${NC}"
  exit
fi

read -p "Do you want create laravel project from scratch or you have one: enter 1-from scratch or 2-have one:  " type
type=$(number_validate $type)
while [ $type -ne 1 -o $type -ne 2 ]; do
  if [ $type -eq 1 ]; then
    echo -e "${PURPLE}Cloning lattes  laravel project ...${NC}"
    git clone https://github.com/laravel/laravel.git $project
    echo -e "${GREEN}Done clone${NC}"
    echo "Deleting old docker config if exist"
    if [ -d "$project/docker" ]; then
      rm -rf "$project/docker"
    fi
    if [ -f "$project/docker-compose.yml" ]; then
      rm  "$project/docker-compose.yml"
    fi
    echo -e "${PURPLE}Creating docker config ...${NC}"

    check_settings_usage

    while [ $projconf -ne 1 -o $projconf -ne 2 ]; do
      if [ $projconf -eq 1 ]; then
        needcopy=1
        break;
      elif [ $projconf -eq 2 ]; then
       while [ "$(ls -A "$project" 2>/dev/null)" == "" ]; do
        echo "Copy your docker settings  and press enter"
        read -p "Press enter to continue:  "
        sleep 1
       done
        break;
      fi
      read -p "Enter only  1 or 2: " projconf
      projconf=$(number_validate $projconf)
    done
    if [ $needcopy -eq 1 ]; then
      cp -a ../config/laravel/. $project/
    fi
    cd $project
    if [ ! -d "docker" ]; then
      mkdir docker
    fi
    cd docker

    php_config

    docker_file

    mysql_config

    nginx_config "laravel"

    host_edit

    docker_compose "laravel"

    docker_run_laravel
    git add .
    git commit -m"initial commit for $project"
    xdg-open https://$project.dev
    echo -e "${PURPLE}Happy coding :) ${NC}"
    sleep 3
    exit
  fi
  if [ $type -eq 2 ]; then
    mkdir $project
    while [ "$(ls -A "$project" 2>/dev/null)" == "" ]; do
      echo "Copy your previous project files to  folder which you just created and press enter"
      read -p "Press enter to continue:  "
      sleep 1
    done
    echo "Deleting old docker config if exist"
    if [ -d "$project/docker" ]; then
      rm -rf "$project/docker"
    fi
    if [ -f "$project/docker-compose.yml" ]; then
      rm  "$project/docker-compose.yml"
    fi
#    if [ -e ".env" ]; then
#        rm .env
#    fi

 while true; do
  echo -en "${BLUE}Is it laravel project?${NC}${YELLOW} (y-yes/n-no)${NC}: "
  read yen
  case $yen in
  [Yy]*) docker_own_project "laravel"  ;;
  [Nn]*) docker_own_project "another";;
  *) echo -e "${YELLOW}Please answer yes or no."${NC} ;;
  esac
done
fi
  read -p "Enter only  1 or 2: " type
  type=$(number_validate $type)
done
